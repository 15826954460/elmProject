<template>
  <div class="integral-wrapper">

    <div class="integral-content">
      <router-link to='/user' class="downLoad-top" tag="h2">
        您还没有积分
      </router-link>
      <p>请返回积分商城重新登陆......</p>
      <img src="//yun.duiba.com.cn/webapp/img/retrylogin.png" alt="">
    </div>

  </div>
</template>
<script>
  export default {
    data () {
      return {}
    }
  }
</script>
<style scoped>
  @import './integral.css';
</style>
