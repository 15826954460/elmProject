<template>
  <section class="food_type">

    <ul class="food_type_nav" ref="menuwrapper">
      <li v-for="(item, index) in shopMenu" :class="{current:currentIndex === index}" @click="selectMenu(index)">
        <img :src="getImgPath(item.icon_url)" alt="" v-if="item.icon_url">{{item.name}}


      </li>
    </ul>

    <ul class="food_type_detail" ref="foodwrapper">
      <li v-for="(item, index) in shopMenu" class="food-list-hook">
        <header>
          <strong>{{item.name}}</strong>
          <p>{{item.description}}</p>
        </header>
        <section class="content" v-for="(foodList, foodIndex) in item.foods">
          <div class="content_left">
            <img :src="getImgPath(foodList.image_path)" v-if="foodList.image_path">
          </div>
          <div class="content_right">
            <h4 class="title">{{foodList.name}}</h4>
            <p class="intro">{{foodList.description}}</p>
            <p class="seller">
              <span>月销{{foodList.month_sales}}份</span>
              <span>好评率{{foodList.satisfy_rate}}%</span>
            </p>
            <div class="change_type">
              <section class="price_wrapper" v-if="foodList.specfoods"><span
                class="price">￥{{foodList.specfoods[0].price}}</span>
                <span>起</span></section>
              <section class="about_buy_num">

                <transition name="fade-buy" mode="out-in">
                  <!--<p class="about_num" v-if="shopCart.cartList">-->
                          <!--<span class="fa fa-minus-square-o" v-show="shopCart.cartList[index][foodIndex].num >0"-->
                                <!--@click="addNum(index, foodIndex, -1)"></span>-->
                    <!--<span class="buy_num"-->
                          <!--v-show="shopCart.cartList[index][foodIndex].num > 0">{{shopCart.cartList[index][foodIndex].num}}</span>-->
                  <!--</p>-->
                </transition>

                <p class="add_num">
                        <span class="fa fa-plus-square" v-if="foodList.specfoods.length<=1"
                              @click="addNum(index, foodIndex, 1)"></span>
                  <span class="norms" v-else @click="normWrapper(foodList)">选规格</span>
                </p>
              </section>
            </div>
          </div>
        </section>
      </li>
    </ul>

    <section class="norms_wrapper" v-if="isShowNormWrapper">
      <div class="content">
        <header>{{foodsList.name}}<i class="fa fa-remove" @click="isShowNormWrapper = false"></i></header>
        <h4>规格</h4>
        <span class="specs" v-for="item in foodsList.specfoods">{{item.specs[0].value}}</span>
        <footer><span>￥</span><span>74</span>
          <button>加入购物车</button>
        </footer>
      </div>
    </section>

  </section>
</template>
<script>
  import {getImgPath} from '../../mixin/getPath'
  import BScroll from 'better-scroll'
  export default {
    data () {
      return {
        isShowNormWrapper: false,
        listHeight: [], // 保存foodwraper中所有li的高度
        scrollY: 0,
        goods: [],
        menuScroll: '',
        foodScroll: ''
      }
    },
    computed: {
      shopMenu () {  // 获取菜品详情信息
        return this.$store.getters.shopMenu
      },
      shopCart () { // 获取购物车数据
        return this.$store.getters.shopCart
      },
      initShopCart () { // 初始化简易的购物车列表
        let shopMenu = this.$store.getters.shopMenu
        let obj = {}
        obj.cartList = []
        for (let i = 0, len = shopMenu.length; i < len; i++) {
          let array = []
          let foods = shopMenu[i].foods
          for (let r = 0, len = foods.length; r < len; r++) {
            let obj = {}
            obj.item_id = foods[r].item_id
            obj.num = 0
            array.push(obj)
          }
          obj.cartList.push(array)
        }
        return obj
      },
      foodsList () {
        return this.$store.getters.foodsList
      },
      // 定义一个计算属性computed，用来计算左侧对应的i值，从而定位到左侧边栏的位置
      currentIndex () {
        for (let i = 0; i < this.listHeight.length; i++) {
          // 判断当currentIndex在height1和height2之间的时候显示
          let height1 = this.listHeight[i]
          let height2 = this.listHeight[i + 1]
          // 最后一个区间没有height2
          if (!height2 || (this.scrollY >= height1 && this.scrollY < height2)) {
            return i
          }
        }
        return 0
      }
    },
    mixins: [getImgPath],
    methods: {
      addNum (index, foodIndex, adv) {
        let count = null
        const commentCode = (cartList, adv) => {  // 提取公用代码
          count = parseInt(cartList.cartList[index][foodIndex].num)
          count = (adv > 0 ? (count + 1) : (count > 0 ? (count - 1) : count)) // 根据点击按钮来判断加减，如果数量等于0则不改变
          count > 0 ? this.shopCartList = true : this.shopCartList = false
          window.localStorage.setItem('shopCartList', this.shopCartList)
          cartList.cartList[index][foodIndex].num = count
          this.$store.commit('setShopCart', cartList)
          window.localStorage.setItem('shopCart', JSON.stringify(cartList)) // 将数据保存到本地
        }
        if (JSON.stringify(this.$store.getters.shopCart) === '{}') { // 判断是否给shopCart是否为{} 如果是，则使用初始化数据
          let cartList = this.initShopCart
          commentCode(cartList, adv)
        } else { // 否则使用已经存在的shopCart
          let cartList = this.$store.getters.shopCart
          commentCode(cartList, adv)
        }
      },
      normWrapper (adv) { // 弹出规格弹框
        this.isShowNormWrapper = true
        this.$store.commit('setFoodsList', adv)
      },
      _initScroll () {
        this.menuScroll = new BScroll((this.$refs.menuwrapper), {
          click: true
        })
        this.foodScroll = new BScroll((this.$refs.foodwrapper), {
          click: true
        })
        // 设置监听滚动位置
        this.foodScroll.on('scroll', (pos) => {
        // scrollY接收变量
          this.scrollY = Math.abs(Math.round(pos.y))
        })
      },
      _calculateHeight () {
        let foodList = this.$refs.foodwrapper.getElementsByClassName('food-list-hook')
        let height = 0
        // 把第一个高度送入数组
        this.listHeight.push(height)
        // 通过循环foodList下的dom结构，将每一个li的高度依次送入数组
        for (let i = 0; i < foodList.length; i++) {
          let item = foodList[i]
          height += item.clientHeight
          this.listHeight.push(height)
        }
      },
      // 左侧点击功能
      selectMenu (index, event) {
//      自己默认派发事件时候(BScroll),_constructed被置为true,但是浏览器原生并没有这个属性
        if (!event._constructed) {
          return
        }
        // 运用BScroll接口，滚动到相应位置
        let foodList = this.$refs.foodwrapper.getElementsByClassName('food-list-hook')
        // 获取对应元素的列表
        let el = foodList[index]
        // 设置滚动时间
        this.foodScroll.scrollToElement(el, 300)
      }
    },
    created () {
      // 页面刷新，获去本地购物车信息，更改axios中的数据
      let win = window.localStorage
      let shopCart = JSON.parse(win.getItem('shopCart'))
      this.$store.commit('setShopCart', shopCart)
      this.$nextTick(() => {
        this._initScroll()
        this._calculateHeight()
      })
    }
  }
</script>

<style scoped>
  @import './shopmenu.css';
</style>
