<template>
  <div class="shop-box">

    <transition name="parent-slide" mode="out-in">
      <div class="shop-wrapper" v-show="$root.showShop">

        <header>
          <section class="header-top">
            <div class="header-left">
              <img :src="getImgPath(shopDetail.image_path)">
            </div>
            <div class="header-right">
              <h2>{{shopDetail.description}}</h2>
              <p>商家配送 / {{shopDetail.order_lead_time}}分钟送达 / 配送费{{shopDetail.float_delivery_fee}}元</p>
              <p class="notice">公告：{{promotionInfo}}</p>
              <i class="fa fa-angle-right" @click="goToShopDetail"></i>
            </div>
          </section>

          <section class="header-bottom" v-if="shopDetail.activities">
            <p @click="showActivitiesFun = true">
              <span :style="{background:'#'+shopDetail.activities[0].icon_color}"
                    class="bottom_one">{{shopDetail.activities[0].icon_name}}</span>
              <span class="bottom_two">{{shopDetail.activities[0].description}}(APP专享)</span>
              <span class="bottom_three">{{shopDetail.activities.length}}个活动</span>
              <span class="fa fa-angle-right"></span>
            </p>
          </section>

          <div class="blur">
            <img :src="getImgPath(shopDetail.image_path)">
          </div>
        </header>

        <transition name="fade">
          <section class="activities_details" v-show="showActivitiesFun">
            <h2 class="activities_shoptitle">{{shopDetail.name}}</h2>
            <section class="activities_list">
              <header class="activities_title_style"><span>优惠信息</span></header>
              <ul>
                <li v-for="item in shopDetail.activities" :key="item.id">
                  <span class="activities_icon"
                        :style="{backgroundColor: '#' + item.icon_color, borderColor: '#' + item.icon_color}">{{item.icon_name}}</span>
                  <span>{{item.description}}（APP专享）</span>
                </li>
              </ul>
            </section>
            <section class="activities_shopinfo">
              <header class="activities_title_style"><span>商家公告</span></header>
              <p>{{promotionInfo}}</p>
            </section>
            <i class="fa fa-remove" @click="showActivitiesFun = false"></i>
          </section>
        </transition>

        <section class="shop_nav">
          <div @click="negative = true">
            <span :class="{negative:negative}">商品</span>
          </div>
          <div @click="negative = false">
            <span :class="{negative:!negative}">评价</span>
          </div>
        </section>

        <shopmenu></shopmenu>

      </div>
    </transition>

    <transition name="children-slide" mode="out-in">
      <router-view></router-view>
    </transition>

  </div>
</template>
<script>
  import {getImgPath} from '../../mixin/getPath'
  import shopmenu from './shopmenu.vue'
  export default {
    data () {
      return {
        negative: true,  // 商品页面
        showActivitiesFun: false // 显示商品详情
      }
    },
    components: {
      shopmenu
    },
    computed: {
      shopDetail () {  // 获取商家详情信息
        return this.$store.getters.shopDetails
      },
      promotionInfo () { // 自定义提示信息
        return this.$store.getters.shopDetails.promotion_info || '欢迎光临，用餐高峰期请提前下单，谢谢。'
      }
    },
    mixins: [getImgPath],
    methods: {
      goToShopDetail () {  // 返回购物车详情页
        this.$root.showShop = false
        window.localStorage.setItem('showShop', false)
        this.$router.push({path: '/shop/shopdetail'})
      }
    },
    created () {
      window.localStorage.getItem('showShop') === null ? this.$root.showShop = true : window.localStorage.getItem('showShop') === 'false' ? this.$root.showShop = false : this.$root.showShop = true
    }
  }
</script>
<style scoped>
  @import './shop.css';
</style>
