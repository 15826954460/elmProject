<template>
  <div class="star">
    <span v-for="n in onCount" class="onCount"></span>
    <span v-for="n in halfCount" class="halfCount"></span>
    <span v-for="n in offCount" class="offCount"></span>
  </div>
</template>

<script>
  export default {
    props: ['rating'],
    data: function () {
      return {
        start: 0,
        onCount: 0, // 满星的个数
        offCount: 0, // 全灰的个数
        halfCount: 0, // 半星的个数
        allNum: 5
      }
    },
    mounted: function () {
      this.start = parseFloat(parseInt(parseFloat(this.rating) * 2) / 2)
      this.onCount = parseInt(this.start)
      if (this.start % 1 === 0) {
        this.offCount = this.allNum - this.start
      } else {
        this.halfCount = 1
        this.offCount = this.allNum - this.onCount - 1
      }
    }
  }
</script>

<style lang="less" scoped>
  @import 'star.css';
</style>

