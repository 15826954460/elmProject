/**
 * Created by lele on 2017/5/5.
 */
import * as getters from './getters'
import * as actions from './actions'
import * as mutations from './mutations'
import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const state = {
  gress_city: '上海',
  shopListNum: '',
  business: [],
  orderList: [],
  orderDetail: {},
  foodTypes: [],
  group_city: {},
  hot_city: {},
  search_data: [],  // 搜索数据
  shopList: [],  // 商铺列表
  orderId: '',  // 订单id
  userInfo: { // 用户信息
    'uName': 'cangdu000',
    'phone': '15826942285',
    'count': 7,
    'balance': '00.0',
    'pointNumber': 0
  },
  add_detail: [], // 地址详情
  address: {  // 地址
    'address': [
      {address: '上海马戏团', phone: 15896451235},
      {address: '华盛达大厦', phone: 15896451235},
      {address: '电影大厦', phone: 15896451235},
      {address: '宏大购物广场', phone: 15896451235},
      {address: '罗湖歌剧院', phone: 15896451235}
    ]
  },
  computedTime: 30, // 发送时间
  userInfomation: true, // 个人用户信息
  service: [],
  hongbaoList: [],  // 红包列表
  shopDetails: {},  // 商店详情
  shopMenu: [],  // 菜品详情
  shopCart: {},  // 购物车列表
  foodsList: {}
}

export default new Vuex.Store({
  state,
  modules: {},
  getters,
  actions,
  mutations
})
