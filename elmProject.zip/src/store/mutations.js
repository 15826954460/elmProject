/**
 * Created by lele on 2017/5/5.
 */
export const setGressCity = (state, setGressCity) => {
  state.gress_city = setGressCity
}
export const setShopListNum = (state, shopLists) => {
  state.shopListNum = shopLists
}
export const setBusiness = (state, business) => {
  state.business = business
}
export const setOrderList = (state, orderList) => {
  state.orderList = orderList
}
export const setOrderDetail = (state, orderDetail) => {
  state.orderDetail = orderDetail
}
export const setFoodTypes = (state, foodTypes) => {
  state.foodTypes = foodTypes
}
export const setGroupCity = (state, groupCity) => {
  state.group_city = groupCity
}
export const setHotCity = (state, hotCity) => {
  state.hot_city = hotCity
}
export const setSearchData = (state, searchData) => {
  state.search_data = searchData
}
export const setShopList = (state, shopList) => {
  state.shopList = shopList
}
// export const setOrderId = (state, orderId) => {
//   state.orderId = orderId
// }
export const setUserInfoName = (state, uName) => {
  state.userInfo.uName = uName
}
export const setAddDetail = (state, addDetail) => {
  state.add_detail = addDetail
}
export const updateAddress = (state, address) => {
  state.address = address
}
export const setComputedTime = (state, computedTime) => {
  state.computedTime = computedTime
}
export const setUserInfomation = (state, userInfomation) => {
  state.userInfomation = userInfomation
}
export const setService = (state, service) => {
  state.service = service
}
export const setHongbaoList = (state, hongbaoList) => {
  state.hongbaoList = hongbaoList
}
export const setShopDetails = (state, shopDetails) => {
  state.shopDetails = shopDetails
}
export const setShopMenu = (state, shopMenu) => {
  state.shopMenu = shopMenu
}
export const setShopCart = (state, shopCart) => {
  state.shopCart = shopCart
}
export const setFoodsList = (state, foodsList) => {
  state.foodsList = foodsList
}
