/**
 * Created by lele on 2017/5/5.
 */
export const gressCity = state => state.gress_city
export const shopListNum = state => state.shopListNum
export const business = state => state.business
export const orderList = state => state.orderList
export const orderDetail = state => state.orderDetail
export const foodTypes = state => state.foodTypes
export const groupCity = state => state.group_city
export const hotCity = state => state.hot_city
export const searchData = state => state.search_data
export const shopList = state => state.shopList
// export const orderId = state => state.orderId
export const userInfo = state => state.userInfo
export const addDetail = state => state.add_detail
// export const inputAdress = state => state.inputAdress
export const address = state => state.address
export const computedTime = state => state.computedTime
export const userInfomation = state => state.userInfomation
export const service = state => state.service
export const hongbaoList = state => state.hongbaoList
export const shopDetails = state => state.shopDetails
export const shopMenu = state => state.shopMenu
export const shopCart = state => state.shopCart
export const foodsList = state => state.foodsList
