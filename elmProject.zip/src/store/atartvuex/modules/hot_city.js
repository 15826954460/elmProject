/**
 * Created by lele on 2017/5/6.
 */
import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
Vue.use(Vuex)
const state = {
  hot_city: {}
}
const getters = {
  hotCity: state => state.hot_city
}
const actions = {
  hotCity ({commit}) {
    axios.get('/api/hot_city').then((res) => {
      commit('setHotCity', res.data.hot_city)
    })
  }
}
const mutations = {
  setHotCity (state, hotCity) {
    state.hot_city = hotCity
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}
