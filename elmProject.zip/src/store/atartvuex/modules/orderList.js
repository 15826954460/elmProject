/**
 * Created by lele on 2017/5/6.
 */
import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
Vue.use(Vuex)
const state = {
  orderList: [],
  orderDetail: {}
}
const getters = {
  orderList: state => state.orderList,
  orderDetail: state => state.orderDetail
}
const actions = {
  orderListData ({commit}) {
    axios.get('/api/orderList').then((res) => {
      commit('setOrderList', res.data.orderList)
    })
  },
  orderDetailData ({commit}) {
    axios.get('/api/orderDetail').then((res) => {
      commit('setOrderDetail', res.data.orderDetail)
    })
  }
}
const mutations = {
  setOrderList (state, orderList) {
    state.orderList = orderList
  },
  setOrderDetail (state, orderDetail) {
    state.orderList = orderDetail
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}
