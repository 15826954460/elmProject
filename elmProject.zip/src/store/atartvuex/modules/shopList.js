/**
 * Created by lele on 2017/5/9.
 */
/**
 * Created by lele on 2017/5/8.
 **/
import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
Vue.use(Vuex)
const state = {
  shopList: []
}
const getters = {
  shopList: state => state.shopList
}
const actions = {
  shopListData ({commit}) {
    axios.get('/api/shopList').then((res) => {
      commit('setShopList', res.data.shopList)
    })
  }
}
const mutations = {
  setShopList (state, shopList) {
    state.shopList = shopList
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}
