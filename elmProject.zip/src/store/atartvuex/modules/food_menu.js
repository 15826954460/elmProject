/**
 * Created by lele on 2017/5/8.
 **/
import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
Vue.use(Vuex)
const state = {
  foodTypes: []
}
const getters = {
  foodTypes: state => state.foodTypes
}
const actions = {
  foodTypesData ({commit}) {
    axios.get('/api/foodTypes').then((res) => {
      commit('setFoodTypes', res.data.foodTypes)
    })
  }
}
const mutations = {
  setFoodTypes (state, foodTypes) {
    state.foodTypes = foodTypes
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}
