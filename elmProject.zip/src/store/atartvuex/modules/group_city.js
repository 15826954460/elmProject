/**
 * Created by lele on 2017/5/6.
 */
import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
Vue.use(Vuex)
const state = {
  group_city: {}
}
const getters = {
  groupCity: state => state.group_city
}
const actions = {
  groupCity ({commit}) {
    axios.get('/api/group_cityData').then((res) => {
      commit('setGroupCity', res.data.group_cityData)
    })
  }
}
const mutations = {
  setGroupCity (state, groupCity) {
    state.group_city = groupCity
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}
