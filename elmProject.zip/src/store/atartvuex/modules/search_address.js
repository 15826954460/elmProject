/**
 * Created by lele on 2017/5/6.
 */
import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
Vue.use(Vuex)
// 设置初始变量
const state = {
  search_data: []
}
// 获取初始值
const getters = {
  searchData: state => state.search_data
}
// 请求json数据
const actions = {
  searchData ({commit}) {
    axios.get('/api/search_data').then((res) => {
      commit('setSearchData', res.data.search_data)
    })
  }
}
// 给初始化的变量赋值
const mutations = {
  setSearchData (state, searchData) {
    state.search_data = searchData
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}

