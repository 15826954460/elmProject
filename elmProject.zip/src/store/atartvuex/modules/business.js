/**
 * Created by lele on 2017/5/8.
 **/
import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
Vue.use(Vuex)
const state = {
  business: []
}
const getters = {
  business: state => state.business
}
const actions = {
  businessData ({commit}) {
    axios.get('/api/business').then((res) => {
      commit('setBusiness', res.data.business)
    })
  }
}
const mutations = {
  setBusiness (state, business) {
    state.business = business
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}
