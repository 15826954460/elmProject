/**
 * Created by lele on 2017/5/5.
 */
// 这里是分开出来单个的模块，进一步的优化已经在index.js中
import hotCity from './modules/hot_city'
import groupCity from './modules/group_city'
import searchCity from './modules/search_address'
import foodTypes from './modules/food_menu'
import shopLists from './modules/shopList'
import business from './modules/business'
import orderList from './modules/orderList'
import * as getters from '../getters'
import * as actions from '../actions'
import * as mutations from '../mutations'
import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const state = {
  gress_city: '上海',
  shopListNum: ''
}

export default new Vuex.Store({
  state,
  modules: {
    hotCity,
    groupCity,
    searchCity,
    foodTypes,
    shopLists,
    business,
    orderList
  },
  getters,
  actions,
  mutations
})

