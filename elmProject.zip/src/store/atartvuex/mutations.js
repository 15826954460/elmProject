/**
 * Created by lele on 2017/5/5.
 */
export const setGressCity = (state, setGressCity) => {
  state.gress_city = setGressCity
}
export const setShopListNum = (state, shopLists) => {
  state.shopListNum = shopLists
}
