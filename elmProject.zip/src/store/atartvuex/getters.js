/**
 * Created by lele on 2017/5/5.
 */
export const gressCity = state => state.gress_city
export const shopListNum = state => state.shopListNum
